<?php
@session_start();
include("config/init.php");
$users = new Users();
$login = $users->login($_POST['email'],$_POST['password']);
if($login){
    if($_SESSION['is_admin']){
        header('Location: '.$cfg['site_url'].'/admin/index.php');
    }
    else{
        header('Location: '.$cfg['site_url'].'/admin/profile.php');
    }    
}
else {
    //rediect if not success    
    header('Location: member-login.html');
}
?>
