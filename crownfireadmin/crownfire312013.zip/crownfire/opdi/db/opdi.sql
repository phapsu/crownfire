-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 11, 2012 at 05:40 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `opdi`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET ucs2 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`) VALUES
(1, 'Erie (LHIN 1)'),
(2, 'South West (LHIN 2)');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `organization` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `fax` varchar(255) CHARACTER SET utf8 NOT NULL,
  `website` varchar(255) CHARACTER SET utf8 NOT NULL,
  `group_id` tinyint(4) NOT NULL COMMENT 'thuoc group tuong ung',
  `welcome` text CHARACTER SET utf8 NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `organization`, `password`, `email`, `phone`, `address`, `fax`, `website`, `group_id`, `welcome`, `is_active`, `is_admin`, `created`, `modified`) VALUES
(1, 'vvvvv', 'dsfadsfadf', '111', 'tumet_iii@yahoo.com', 'dsfads', 'dsfa', 'dsfa', 'dsfa', 1, 'dfadsafsda', 1, 0, '2012-12-08 00:00:00', '2012-12-10 22:09:24'),
(2, 'dsfa', 'dsfa', '111', 'admin@gmail.com', '', '', '', '', 1, 'Welcome to opdi.ca', 1, 1, '2012-12-04 00:00:00', NULL),
(3, 'dsfa', 'dsfa', '111', 'abc@gmail.com', '', '', '', '', 1, 'Welcome to opdi.ca', 1, 0, '0000-00-00 00:00:00', NULL),
(4, 'sfda', 'dsfasd', '111', 'dsfa@yahoo.com', '', '', '', '', 2, 'Welcome to opdi.ca', 0, 0, '0000-00-00 00:00:00', NULL),
(5, 'dfs', 'dsfa', '111', 'tumet_ii@yahoo.com', '', '', '', '', 2, 'Welcome to opdi.ca', 0, 0, '2012-12-11 00:00:00', NULL),
(6, '', '', '', '', '', '', '', '', 0, '', 0, 0, '0000-00-00 00:00:00', NULL),
(7, '', '', '', '', '', '', '', '', 0, '', 0, 0, '2012-12-08 17:13:06', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
