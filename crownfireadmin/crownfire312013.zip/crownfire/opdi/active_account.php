<?php
include("config/init.php");

$code = @$_REQUEST['code'];

$code= base64_decode($code);

$pieces = explode("=", $code);

$user_id= $pieces[1]; 

$users = new Users();
$result = $users->active_account($user_id);
if($result)    header('Location: active_success.html');

?>
