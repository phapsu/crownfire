<?php
$cfg = array();
// Is the site up?  You can set to false while you do updates.
$cfg['site_up'] 	   = 	true;
// General Config Settings
// Turning this on simple lets me run the setup on my localhost.  
// Good for how I prefer to edit, and then upload.
// Unfortunately I don't even have a good SVN system yet.
$cfg['mode']			= 'live'; // dev/live

// Name
$cfg['site_name'] 		= 'Opdi';

// welcome
$cfg['welcome'] 		= 'Welcome to opdi.ca';

// Who does mail come from?
$cfg['mail_from']		= array('from' => 'Opdi', 'email' => 'info@opdi.com');
// TODO
// Which messageBoards are MEMBERS ONLY.  This sucks.  This array 
// should be built from values in the database.
$cfg['admin_directory']		= 'admin';

// Connections and linking.  ***Never a trailing slash***
if ($cfg['mode'] == 'live') {
	$cfg['site_url'] 			= 'http://crownfire.onlyoneweb.com/opdi';
	$cfg['db_server']			= 'localhost';
	$cfg['db_username']			= 'opdi_demo';
	$cfg['db_password']			= 'after2011';
	$cfg['db_name']			= 'opdi_demo';
	$cfg['log_directory']		= $cfg['site_url'].'/logs';
	$cfg['include_directory']	       = $cfg['site_url'].'/'.$cfg['admin_directory'].'/includes';
	$cfg['image_save_directory']       = $cfg['site_url'].'/document_images';
	$cfg['image_save_url']		= $cfg['site_url'].'/document_images';	
} else {
	$cfg['site_url'] 			= 'http://opdi.dev:8080';
	$cfg['db_server']			= 'localhost';
	$cfg['db_username']			= 'root';
	$cfg['db_password']			= '';
	$cfg['db_name']				= 'opdi';	
}

// Other settings
$cfg['site_options']			= array('show_user_window' => 1);
$cfg['date_format']				= 'F jS, Y H:i:s';

// Log SQL errors?  I think a good idea.  Hopefully there are none, however.
$cfg['log_sql_errors'] =	true;
//error_reporting(0);

?>