<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>

        <!--META KEYWORDS-->
        <title>OPDI Member Login Ontario Peer Development Initiative | OPDI</title>
        <link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <meta name="description" content="Member Login"/>
        <meta name="keywords" content="Ontario Peer Development Initiative | OPDI "/>
        <meta name="robots" content="index, follow">
        <meta name="revisit-after" content="5 Days">
        <meta name="language" content="EN">
        <meta name="copyright" content="Web Response Web Designs Inc, 2012">
        <meta name="author" content="Web Response"/>


        <!--CSS FILES STARTS-->
        <link rel="shortcut icon" type="image/gif" href="images/favicon.gif"/>
        <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen"/>
        <link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen"/>
        <link rel="stylesheet" id="skins-switcher" href="css/style.css" type="text/css" media="screen"/>
        <link href='http://fonts.googleapis.com/css?family=Cambo' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/newsletter.css" type="text/css" media="screen"/>
        <!--JS FILES STARTS-->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script src="http://maps.google.com/maps/api/js?sensor=false"></script>
        <script type="text/javascript" src="js/custom.js"></script>
        <script type="text/javascript" src="js/jqueryTools/jquery.tools.min.js"></script>
        <script type="text/javascript" src="js/slides/slides.min.jquery.js"></script>
        <script type="text/javascript" src="js/cycle-slider/cycle.js"></script>
        <script type="text/javascript" src="js/nivo-slider/jquery.nivo.slider.js"></script>
        <script type="text/javascript" src="js/tabify/jquery.tabify.js"></script>
        <script type="text/javascript" src="js/prettyPhoto/jquery.prettyPhoto.js"></script>
        <script type="text/javascript" src="js/twitter/jquery.tweet.js"></script>
        <script type="text/javascript" src="js/scrolltop/scrolltopcontrol.js"></script>
        <script type="text/javascript" src="js/portfolio/filterable.js"></script>
        <script type="text/javascript" src="js/kwicks/jquery.kwicks-1.5.1.pack.js"></script>
        <script type="text/javascript" src="js/easing/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="js/google-map/jquery.gmap.min.js"></script>
        <script type="text/javascript" src="js/tipsy/jquery.tipsy.js"></script>
        <script src="js/cufon-fonts/cufon.js" type="text/javascript"></script>
        <script src="js/cufon-fonts/cufon.museo.js" type="text/javascript"></script>
        <script src="js/cufon-fonts/cufon-settings.js" type="text/javascript"></script>
        <script src="js/content-Scroll/jquery.localscroll-min.js" type="text/javascript"></script> 

        <link href="Level1_Arial.css" rel="stylesheet" type="text/css">
        <style type="text/css">
            .Footer-White {
                font-family: Verdana, Geneva, sans-serif;
                color: #CCC;
                font-size: 11px;
            }

            .error{ color:#CC0000; font-size:12px; margin:4px; font-style:italic; width:200px;}

            .success{ color:#009900; font-size:12px; margin:4px; font-style:italic; width:200px;}

            .errorMessage{
                background: url(../images/32block.png) 15px 50% no-repeat #ffd6d4;
                border-color: #911f1a;
                border: 3px solid;
                border-width: 3px 0;
                padding: 15px 15px 15px 65px;
                color: #444;
                margin: 10px 0;
                -moz-border-radius: 15px;
            }
        </style>

        <script type="text/javascript">   
            
            var $ob = jQuery.noConflict();
            
            $ob(function() {

                $ob('#send').click(function() {
                       
                    // name			
                    var nameVal = $ob("#name").val();
                    if(nameVal == '') {
				
                        $ob("#name_error").html('');
                        $ob("#name").after('<label class="error" id="name_error">Please enter your name.</label>');
                        return false
                    }
                    else
                    {
                        $ob("#name_error").html('');
                    }   
                    
                    // organization			
                    var organizationVal = $ob("#organization").val();
                    if(organizationVal == '') {
				
                        $ob("#organization_error").html('');
                        $ob("#organization").after('<label class="error" id="organization_error">Please enter your organization.</label>');
                        return false
                    }
                    else
                    {
                        $ob("#organization_error").html('');
                    }    
                        
                    /// email validation			
                    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                    var emailaddressVal = $ob("#email").val();
			
                    if(emailaddressVal == '') {
                        $ob("#email_error").html('');
                        $ob("#email").after('<label class="error" id="email_error">Please enter your email address.</label>');
                        return false
                    }
                    else if(!emailReg.test(emailaddressVal)) {
                        $ob("#email_error").html('');
                        $ob("#email").after('<label class="error" id="email_error">Enter a valid email address.</label>');
                        return false
			 
                    }
                    else
                    {
                        $ob("#email_error").html('');
                    }
                    
                    // group_id			
                    var group_idVal = $ob("#group_id").val();
                    if(group_idVal == '') {
				
                        $ob("#group_id_error").html('');
                        $ob("#group_id").after('<label class="error" id="group_id_error">Please select your position.</label>');
                        return false
                    }
                    else
                    {
                        $ob("#group_id_error").html('');
                    } 
                    
                    // password validation			
                    var passwordVal = $ob("#password").val();
                    if(passwordVal == '') {
				
                        $ob("#password_error").html('');
                        $ob("#password").after('<label class="error" id="password_error">Please enter your password.</label>');
                        return false
                    }
                    else
                    {
                        $ob("#password_error").html('');
                    }
                    
                    //confirm password
                    var confirm_passwordVal = $ob("#confirm_password").val();
                    if(confirm_passwordVal == '') {
				
                        $ob("#confirm_password_error").html('');
                        $ob("#confirm_password").after('<label class="error" id="confirm_password_error">Please enter your confirm password.</label>');
                        return false
                    }
                    else if(confirm_passwordVal != passwordVal) {
				
                        $ob("#confirm_password_error").html('');
                        $ob("#confirm_password").after('<label class="error" id="confirm_password_error">Your confirm password is incorrect.</label>');
                        return false
                    }
                    else
                    {
                        $ob("#confirm_password_error").html('');
                    }
                    
                    $ob.post('http://opdi.dev:8080/do_register.php', jQuery("#registerForm").serialize(), function(data) {
                        if(data==1){    
                            window.location.href='http://opdi.dev:8080/thanks.html';
                        }else if(data==0){                            
                            $ob('#send').after('<label class="error" id="after_submit">Error ! invalid captcha code .</label>');
                            return false;
                        }else if(data==2){                            
                            $ob('#send').after('<label class="error" id="after_submit">Your Email already registered on this web site.</label>');
                            return false;
                        }
                        else{ 
                            $ob('#send').after('<label class="error" id="after_submit">Sorry, there was an error with your submission. Please try again.</label>');
                            return false;
                        }
                    });   
                    
                    return false;
                });
            });
            
            

        </script>   

        <script type="text/javascript">

            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-35342485-1']);
            _gaq.push(['_trackPageview']);

            (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>    

    </head>
    <body>
        <div id="wrapper">
            <div id="center-page">
                <div id="container">
                    <div id="pre-header">
                        <ul id="pre-header-links">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="member-login.html">Member Login</a></li>
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="contact.html">Contact</a></li>
                        </ul>
                        <ul id="header-icons">
                            <li class="icon-facebook" title="Like OPDI on Facebook" id="social-01"><a href="https://www.facebook.com/ontario.initiative" target="_blank"></a></li>
                            <li class="icon-twitter" title="Follow OPDI on Twitter" id="social-02"><a href="https://twitter.com/intent/user?screen_name=OPDI" target="_blank"></a></li>
                            <li class="icon-youtube" title="OPDI Youtube Page" id="social-07"><a href="http://www.youtube.com/watch?feature=player_embedded&v=gnTJYtzlVkc" target="_blank"></a></li>
                            <li class="icon-linkedin" title="Link In With OPDI" id="social-08"><a href="http://www.linkedin.com" target="_blank"></a></li>
                        </ul>
                    </div>
                    <div id="header">
                        <!-- LOGO -->
                        <a id="logo" title="OPDI" href="index.html"></a>
                        <!--LOGO ENDS  -->
                        <div id="main_navigation" class="main-menu ">
                            <!--  MAIN  NAVIGATION-->
                            <ul>

                                <li><a href="about.html">About</a>
                                    <ul>
                                        <li><a href="staff.html">Our Staff</a></li>
                                        <li><a href="board.html">Board of Directors</a></li>
                                        <li><a href="faq.html">F.A.Q.</a></li>
                                    </ul>
                                </li>
                                <li><a href="members.html">Members</a></li>
                                <li><a href="training.html">Training</a>
                                    <ul>
                                        <li><a href="opdi-core-essentials-training.html">OPDI Core Essentials Training Program</a></li>
                                    </ul>
                                </li>
                                <li><a href="awards.html">Awards</a></li>
                                <li><a href="news.html">News & Events</a></li>
                                <li><a href="resources.html">Resources</a></li>
                            </ul>

                        </div>
                    </div>
                    <div class="inner-page-intro">
                        <h4> OPDI Members</h4>
                        <ul class="breadcrumbs">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="members.html" class="active">Our Members</a></li>
                        </ul>
                    </div>
                    <div class="big-divider">
                    </div>
                    <div id="content">
                        <div class="one">
                            <div id="services">
                                <div class="one">
                                    <div class="inner-content">

                                        <div style="display: block;">
                                            
                                            <h2>Register</h2>
                                            <form method="post" action="do_register.php" name="registerForm" id="registerForm">
                                                <label>Your Name(*)</label> 
                                                <input type="text" class="txt" name="name" id="name">
                                                <br clear="all" />
                                                <label>Your Organization(*)</label>
                                                <input type="text" class="txt" name="organization" id="organization">
                                                <br clear="all" />
                                                <label>Your Address</label>
                                                <input type="text" class="txt" name="address" id="address">
                                                <br clear="all" />
                                                <label>Your Phone</label>
                                                <input type="text" class="txt" name="phone" id="phone">
                                                <br clear="all" />
                                                <label>Your Fax</label>
                                                <input type="text" class="txt" name="fax" id="fax">
                                                <br clear="all" />
                                                <label>Your E-mail(*)</label>
                                                <input type="text" class="txt" name="email" id="email">
                                                <br clear="all" />
                                                <label>Your Website</label>
                                                <input type="text" class="txt" name="website" id="website">
                                                <br clear="all" />
                                                <?php
                                                @session_start();
                                                include("config/init.php");
                                                $groups = new Groups();
                                                $list_groups = $groups->getGroupList();                                                
                                                ?>
                                                <label>Your Position(*)</label> 
                                                <select id="group_id" name="group_id" style="height: 24px; width: 440px;">
                                                    <option value="">----Select your position----</option>
                                                    <?php foreach($list_groups as $row){ ?>
                                                        <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                                    <?php } ?>                                                    
                                                </select>
                                                <br clear="all" />
                                                <label>Your Password(*)</label>
                                                <input type="password" class="txt" name="password" id="password">
                                                <br clear="all" />
                                                <label>Confirm Password(*)</label>
                                                <input type="password" class="txt" name="confirm_password" id="confirm_password">
                                                <br clear="all" />
                                                <?php
                                                $gen = '';
                                                for ($i = 0; $i < 13; $i++) {
                                                    $gen .= rand(0, 9);
                                                }
                                                ?>
                                                <label for="captcha"><img src="captcha.php?gen=<?php echo $gen; ?>"/></label>
                                                <input type="text" id="captcha" name="code" class="txt" style="width:150px;">
                                                <span id="loading_msg"></span>

                                                <br clear="all" />
                                                <input type="submit" class="button" value="Submit" name="submit" id="send">  
                                            </form>
                                        </div>
                                    </div>
                                    <div class="one-fourth last">
                                        <div class="one-fourth">
                                            <h4>&nbsp; </h4>
                                        </div>
                                        <p>&nbsp;</p>
                                        <h4>&nbsp;</h4>
                                        <div class="one-fourth"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="footer-container">
                        <!-- FOOTER CONTAINER STARTS-->
                        <div id="footer">
                            <!-- FOOTER STARTS-->
                            <div class="one">
                                <!-- COLUMN CONTAINER STARTS-->
                                <div class="one-fourth">
                                    <!-- COLUMN STARTS-->
                                    <h4>About OPDI</h4>
                                    <p>
                                        <a href="#"><img src="images/opdi-footer.jpg" alt=" " class="img-align-left"/></a><span class="Footer-White">Ontario Peer Development Initiative’s mission is to acquire, understand and amplify th unique and distinct voice of consumer/ survivor organizations across Ontario. The experiential expertise of our peers will shape the mental health system to achieve a valued, recovery- oriented, community-base approach to support. </span></p>
                                    <br/>
                                    <ul id="footer-info">
                                        <li class="Footer-White"></li>
                                        <!-- SOCIAL LINKS ENDS-->
                                    </ul>
                                </div>
                                <!-- COLUMN ENDS-->
                                <div class="one-fourth">
                                    <!-- COLUMN STARTS-->
                                    <h4> Address</h4>

                                    <h4><em>~ By Appointment Only ~ </em></h4>
                                    <ul id="footer-info2">
                                        <li class="Footer-White">OPDI<br>
					        Centre for Social Innovation - Annex </li>
                                        <li class="Footer-White">Toronto, Ontario <br>
					        M5S 2R4</li>
                                        <li class="Footer-White">Local: (416) 484-8785</li>
                                        <li class="Footer-White">Toll Free: 1-866-681-6661</li>
                                        <li class="Footer-White">Email: <a href="opdi@opdi.org" class="colored">opdi@opdi.org</a></li><br>

                                        <!-- SOCIAL LINKS ENDS-->
                                    </ul>
                                    <br>
                                </div>
                                <!-- COLUMN ENDS-->
                                <div class="one-fourth">
                                    <!-- COLUMN STARTS-->
                                    <h4>Navigation</h4>
                                    <ul class="blog-post-homepage">
                                        <li><a href="index.html">Home Page</a></li>
                                        <li><a href="about.html">Learn About  OPDI</a></li>
                                        <li><a href="members.html">Our Members in Ontario</a></li>
                                        <li><a href="training.html">Training</a></li>
                                        <li><a href="awards.html">Awards</a></li>
                                        <li><a href="news.html">News &amp; Events</a></li>
                                        <li><a href="resources.html">Resources</a></li>

                                    </ul>

                                </div>

                                <div class="one-fourth last">
                                    <h4>Get Social With OPDI</h4>
                                    <h1> <a href="http://www.linkedin.com/" target="_blank"><img src="images/icons/linkedin_logo30.png" alt=" " width="36" height="36" class="img-align-left"/></a><span class="Footer-White"><a href="http://www.linkedin.com/" target="_blank">Link In with our Staff</a></span></h1>
                                    <br/>
                                    <h1> <a href="http://www.flickr.com"><img src="images/icons/flickr_box_36.png" alt=" " width="36" height="36" class="img-align-left"/></a><span class="Footer-White"><a href="http://www.flickr.com" target="_blank">View Our Flickr Pictures</a></span></h1>
                                    <br/>
                                    <h1> <a href="https://twitter.com/intent/user?screen_name=OPDI" target="_blank"><img src="images/icons/twitter_logo.png" alt=" " width="36" height="36" class="img-align-left"/></a><span class="Footer-White"><a href="https://twitter.com/intent/user?screen_name=OPDI" target="_blank">Follow Us on Twitter</a></span></h1>
                                    <br/>

                                    <h1> <a href="http://www.youtube.com" target="_blank"><img src="images/icons/youtube.png" alt=" " width="36" height="36" class="img-align-left"/></a><span class="Footer-White"><a href="http://www.youtube.com" target="_blank">View our Youtube Channel</a></span></h1>
                                    <br/>
                                    <ul id="footer-info3">
                                        <li class="Footer-White"></li>
                                        <!-- SOCIAL LINKS ENDS-->
                                    </ul>
                                </div>
                                <!-- COLUMN ENDS-->
                            </div>
                            <!-- COLUMN CONTAINER ENDS-->
                        </div>
                        <!-- FOOTER ENDS-->
                    </div>
                    <div id="copyrights">
                        <p>
                            &copy; Copyright 2012. All Rights Reserved. <a href="http://webresponse.ca" title="Web Design Mississauga" target="_blank">Web Design Mississauga</a> </p>
                        <ul id="footer-links">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="member-login.html">Member Login</a></li>
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="contact.html">Contact</a></li>
                            <li><a href="#" class="backtotop">&uarr;</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>