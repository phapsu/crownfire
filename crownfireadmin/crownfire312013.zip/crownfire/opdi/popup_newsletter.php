<script type="text/javascript" src="js/newsletter.js"></script>
<!-- hidden inline form -->
<h2>Send us your information</h2>
<?php
$gen = $_GET["gen"];
?>
<form id="contactForm" name="contact" action="#" method="post">
		<label for="name">Name</label>
		<input type="text" id="name" name="name" class="txt">
		<br>
		<label for="Organization">Organization</label>
		<input type="text" id="organization" name="organization" class="txt">
		<br>
		<label for="email">Your E-mail</label>
		<input type="text" id="email" name="email" class="txt">
		<br>
		<label for="captcha"><img src="captcha.php?gen=<?php echo $gen;?>"/></label>
		<input type="text" id="captcha" name="code" class="txt" style="width:150px;">
		<span id="loading_msg"></span>
		<input type="submit" id="send" name="submit" value="Submit" class="button" />
</form>
