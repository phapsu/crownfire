	var $ob = jQuery.noConflict();
	
	function validateEmail(email) { 
		var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return reg.test(email);
	}

	function reloadEmail(){
		$email = $ob('#footer-form-email').val();
		if($email != 'Email *'){
			$ob('#email').val($ob('#footer-form-email').val());
		}
	}
	
	
	$ob(function() {
	
	
		$ob(".modalbox").fancybox();
		$ob("#contactForm").submit(function() { return false; });

		
		$ob("#send").on("click", function(){
		
			var emailval  = $ob("#email").val();
			var msgval    = $ob("#name").val();
			var msgcode    = $ob("#captcha").val();
			var msglen    = msgval.length;
			var codelen    = msgcode.length;
			var mailvalid = validateEmail(emailval);
			
			if(mailvalid == false) {
				$ob("#email").addClass("error");
			}
			else if(mailvalid == true){
				$ob("#email").removeClass("error");
			}
			
			if(msglen < 4) {
				$ob("#name").addClass("error");
			}
			else if(msglen >= 4){
				$ob("#name").removeClass("error");
			}
			
			if(codelen <= 0) {
				$ob("#captcha").addClass("error");
			}
			else if(codelen > 0){
				$ob("#captcha").removeClass("error");
			}
			
			if(mailvalid == true && msglen >= 4 && codelen > 0) {
				// if both validate we attempt to send the e-mail
				// first we hide the submit btn so the user doesnt click twice
				$ob("#send").hide();
				$ob('#loading_msg').html("<em>sending...</em>");
				$ob('#loading_msg').show();
				
				$ob.post(	'sendmessage.php', 
							{
								'name' : $ob("#name").val(),
								'organization' : $ob("#organization").val(),
								'email' : $ob("#email").val(),
								'code' : $ob("#captcha").val()
							},
							function(data) {
								if(data == "true") {
									$ob("#inline").fadeOut("fast", function(){
										$ob(this).before("<p><strong>Success! Your information has been sent, Thank you.</strong></p>");
										setTimeout("$ob.fancybox.close()", 1000);
										$ob('#loading_msg').hide();
										$ob("#send").show();
									});
								}else if(data == "captcha"){
									$ob("#captcha").addClass("error");
									$ob('#loading_msg').hide();
									$ob("#send").show();
								}
							}
				);				
			}
		});
	});