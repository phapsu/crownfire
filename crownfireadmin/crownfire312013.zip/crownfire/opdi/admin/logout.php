<?php

@session_start();
include("init.php");
unset($_SESSION['is_admin']);
unset($_SESSION['is_login']);
unset($_SESSION['user_id']);

header('Location: '.$cfg['site_url'].'/member-login.html');
?>
