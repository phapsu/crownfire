<?php
@session_start();
if(!isset($_SESSION['is_login']) || !($_SESSION['is_login'])) {
    header('Location: '.$cfg['site_url'].'/member-login.html');
}

include("init.php");
$users = new Users();
$user = $users->getUserInfo($_SESSION['user_id']);
$groups = new Groups();
$list_groups = $groups->getGroupList();
?>  

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
    <head>
        <title>Opdi User Page</title>
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
        <link href="css/styles.css" rel="stylesheet" />
        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script>
        <link rel='shortcut icon' href="img/favicon.ico" type="image/x-icon" />	
        <style>
            .error{
                color: Red;
                font-weight: bold;
                margin-left: 10px;
            }
            .success{
                color: blueviolet;
                font-weight: bold;
                margin-left: 10px;
            }
        </style>
        <script>
            
            $(function() {

                $('#send').click(function() {
                    $('#after_submit').remove();   
                       
                    // name			
                    var nameVal = $("#name").val();
                    if(nameVal == '') {
				
                        $("#name_error").html('');
                        $("#name").after('<label class="error" id="name_error">Please enter your name.</label>');
                        return false
                    }
                    else
                    {
                        $("#name_error").html('');
                    }   
                    
                    // organization			
                    var organizationVal = $("#organization").val();
                    if(organizationVal == '') {
				
                        $("#organization_error").html('');
                        $("#organization").after('<label class="error" id="organization_error">Please enter your organization.</label>');
                        return false
                    }
                    else
                    {
                        $("#organization_error").html('');
                    }    
                        
                    /// email validation			
                    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                    var emailaddressVal = $("#email").val();
			
                    if(emailaddressVal == '') {
                        $("#email_error").html('');
                        $("#email").after('<label class="error" id="email_error">Please enter your email address.</label>');
                        return false
                    }
                    else if(!emailReg.test(emailaddressVal)) {
                        $("#email_error").html('');
                        $("#email").after('<label class="error" id="email_error">Enter a valid email address.</label>');
                        return false
			 
                    }
                    else
                    {
                        $("#email_error").html('');
                    }
                    
                    // group_id			
                    var group_idVal = $("#group_id").val();
                    if(group_idVal == '') {
				
                        $("#group_id_error").html('');
                        $("#group_id").after('<label class="error" id="group_id_error">Please select your position.</label>');
                        return false
                    }
                    else
                    {
                        $("#group_id_error").html('');
                    }                                       
                    
                    //confirm password
                    var new_passwordVal = $("#new_password").val();
                    var confirm_passwordVal = $("#confirm_password").val();
                    
                    if(new_passwordVal != '') {
                        if(confirm_passwordVal==''){
				
                            $("#confirm_password_error").html('');
                            $("#confirm_password").after('<label class="error" id="confirm_password_error">Please enter your confirm password.</label>');
                            return false
                        }
                        else if(confirm_passwordVal != new_passwordVal) {
				
                            $("#confirm_password_error").html('');
                            $("#confirm_password").after('<label class="error" id="confirm_password_error">Your confirm password is incorrect.</label>');
                            return false
                        }
                        else
                        {
                            $("#confirm_password_error").html('');
                        }
                    }                    
                    
                    $('#after_submit').remove();
                    $('#send').after('<img id="after_submit" src="images/ajax-loader.gif"/>');
                    $.post('do_profile.php', $("#editForm").serialize(), function(data) {
                        if(data==1){  
                            $('#after_submit').remove();
                            $('#send').after('<label class="error" id="after_submit">Your Email already registered on this web site.</label>');
                            return false;
                        }else if(data==2){
                            $('#after_submit').remove();
                            $('#send').after('<label class="success" id="after_submit">Your profile was updated successfully.</label>');
                        }
                        else{ 
                            $('#after_submit').remove();
                            $('#send').after('<label class="error" id="after_submit">Sorry, there was an error with your submission. Please try again.</label>');
                            return false;
                        }
                    });   
                    
                    return false;
                });
            });
        </script>
    </head>
    <body>
        <div id="tupperware">
            <div id="status">
                <a href="<?php echo $cfg['site_url']; ?>" style="color: #fff;">Home</a> | <a href="logout.php?id=<?php echo @$user['id']; ?>" style="color: #fff;">Logout</a>
            </div>
            <h2>Opdi User Page</h2>                      
            <table width="100%">    
                <tr>
                    <td>
                        <fieldset>
                            <legend>Welcome back <b><?php echo @$user['name']; ?></b></legend>
                            <table width="99%">
                                <tr valign="top">
                                    <td width="15%"><img border="0" src="images/icon_seo.png" width="48" height="48" /></td>
                                    <td width="85%">
                                        <?php echo @nl2br($user['welcome']); ?>
                                    </td>
                                </tr>
                            </table>
                        </fieldset>

                    </td>

                </tr>
                <tr>
                    <td>
                        <fieldset>
                            <legend>Information:</legend>
                            <table width="99%">
                                <tr valign="top">
                                    <td width="15%"><img border="0" src="images/user-group-icon.png" /></td>
                                    <td width="85%">
                                        <form method="post" action="do_profile.php" name="editForm" id="editForm">
                                            <input type="hidden" name="id" id="id" value="<?php echo @$user['id']; ?>"/>
                                            <table width="100%">
                                                <tr>
                                                    <td width="40%">Name</td>
                                                    <td width="60%"><input type="text" name="name" id="name" value="<?php echo @$user['name']; ?>"/></td>
                                                </tr>
                                                <tr>
                                                    <td>Organization</td>
                                                    <td><input type="text" name="organization" id="organization" value="<?php echo @$user['organization']; ?>"/></td>
                                                </tr>
                                                <tr>
                                                    <td>Address</td>
                                                    <td><input type="text" name="address" id="address" value="<?php echo @$user['address']; ?>"/></td>
                                                </tr>
                                                <tr>
                                                    <td>Phone</td>
                                                    <td><input type="text" name="phone" id="phone" value="<?php echo @$user['phone']; ?>"/></td>
                                                </tr>
                                                <tr>
                                                    <td>Fax</td>
                                                    <td><input type="text" name="fax" id="fax" value="<?php echo @$user['fax']; ?>"/></td>
                                                </tr>
                                                <tr>
                                                    <td>E-mail</td>
                                                    <td><input type="text" name="email" id="email" value="<?php echo @$user['email']; ?>"/></td>
                                                </tr>
                                                <tr>
                                                    <td>Website</td>
                                                    <td><input type="text" name="website" id="website" value="<?php echo @$user['website']; ?>"/></td>
                                                </tr>
                                                <tr>
                                                    <td>Position</td>
                                                    <td>
                                                        <select id="group_id" name="group_id" style="height: 24px; width: 308px;">
                                                            <option value="">----Select your position----</option>
                                                            <?php foreach ($list_groups as $row) {
                                                                if (@$row['id'] == $user['group_id']) { ?>
                                                                    <option value="<?php echo $row['id']; ?>" selected><?php echo $row['name']; ?></option>
                                                                <?php } else { ?>
                                                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                                                <?php }
                                                            } ?>                                                    
                                                        </select>                                                    
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>New Password</td>
                                                    <td><input type="password" name="new_password" id="new_password" value=""/></td>
                                                </tr>
                                                <tr>
                                                    <td>Confirm Password</td>
                                                    <td><input type="password" name="confirm_password" id="confirm_password" value=""/></td>
                                                </tr>
                                                <tr>
                                                    <td>&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td>&nbsp;</td>
                                                    <td><button type="button" name="button" id="send" value="submit"/>submit</button></td>
                                                </tr>
                                            </table>
                                        </form>
                                    </td>
                                </tr>
                            </table>
                        </fieldset>
                    </td>        
                </tr>


            </table>

    </body>
</html>