<?php
@session_start();
if (!isset($_SESSION['is_admin']) || !($_SESSION['is_admin'])) {
    header('Location: ' . $cfg['site_url'] . '/member-login.html');
}

if (isset($_REQUEST['user_id']) && $_REQUEST['user_id'] != '') {
    include("init.php");
    $users = new Users();
    $user = $users->getUserInfo($_REQUEST['user_id']);
} else {
    header('Location: user.php');
}

$groups = new Groups();
$list_groups = $groups->getGroupList();
?>  

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
    <head>
        <title>Opdi Admin Page</title>
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
        <link href="css/styles.css" rel="stylesheet" />
        <script type="text/javascript" src="scripts/jquery-1.3.2.min.js"></script>
        <script type="text/javascript" src="scripts/jquery-ui-1.7.2.custom.min.js"></script>
        <link rel="Stylesheet" type="text/css" href="style/jqueryui/ui-lightness/jquery-ui-1.7.2.custom.css" />

        <script type="text/javascript" src="scripts/jHtmlArea-0.7.0.js"></script>
        <link rel="Stylesheet" type="text/css" href="style/jHtmlArea.css" />

        <style type="text/css">
            /* body { background: #ccc;} */
            div.jHtmlArea .ToolBar ul li a.custom_disk_button 
            {
                background: url(images/disk.png) no-repeat;
                background-position: 0 0;
            }

            div.jHtmlArea { border: solid 1px #ccc; }
        </style>
        <style>
            .error{
                color: Red;
                font-weight: bold;
                margin-left: 10px;
            }
            .success{
                color: blueviolet;
                font-weight: bold;
                margin-left: 10px;
            }
        </style>
        <script>
            
            $(function() {
                
                $("#welcome").htmlarea();

                $('#send').click(function() {
                    
                    $('#after_submit').remove();   
                       
                    // name			
                    var nameVal = $("#name").val();
                    if(nameVal == '') {
				
                        $("#name_error").html('');
                        $("#name").after('<label class="error" id="name_error">Please enter your name.</label>');
                        return false
                    }
                    else
                    {
                        $("#name_error").html('');
                    }   
                    
                    // organization			
                    var organizationVal = $("#organization").val();
                    if(organizationVal == '') {
				
                        $("#organization_error").html('');
                        $("#organization").after('<label class="error" id="organization_error">Please enter your organization.</label>');
                        return false
                    }
                    else
                    {
                        $("#organization_error").html('');
                    }    
                        
                    /// email validation			
                    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                    var emailaddressVal = $("#email").val();
			
                    if(emailaddressVal == '') {
                        $("#email_error").html('');
                        $("#email").after('<label class="error" id="email_error">Please enter your email address.</label>');
                        return false
                    }
                    else if(!emailReg.test(emailaddressVal)) {
                        $("#email_error").html('');
                        $("#email").after('<label class="error" id="email_error">Enter a valid email address.</label>');
                        return false
			 
                    }
                    else
                    {
                        $("#email_error").html('');
                    }
                    
                    // group_id			
                    var group_idVal = $("#group_id").val();
                    if(group_idVal == '') {
				
                        $("#group_id_error").html('');
                        $("#group_id").after('<label class="error" id="group_id_error">Please select your position.</label>');
                        return false
                    }
                    else
                    {
                        $("#group_id_error").html('');
                    }                                       
                    
                    //confirm password
                    var passwordVal = $("password").val();                                        
                    
                    if(passwordVal==''){

                        $("#password_error").html('');
                        $("#password").after('<label class="error" id="password_error">Please enter your password.</label>');
                        return false
                    }                   
                    else
                    {
                        $("#password_error").html('');
                    }
                                   
                    
                    $('#after_submit').remove();
                    $('#send').after('<img id="after_submit" src="images/ajax-loader.gif"/>');
                 
                    var is_active;
                    if ($('#is_active').is(':checked')) {
                        is_active=1;
                    } else {
                        is_active=0;
                    }
                    
                    var data = {
                        'id': $('#id').val(),
                        'name': $('#name').val(),
                        'organization': $('#organization').val(),
                        'address': $('#address').val(),
                        'phone': $('#phone').val(),
                        'fax': $('#fax').val(),
                        'email': $('#email').val(),
                        'website': $('#website').val(),
                        'group_id': $('#group_id').val(),
                        'password': $('#password').val(),
                        'is_active': is_active,
                        'welcome': $('#welcome').htmlarea('toHtmlString')
                    }
                    
                    $.ajax({
                        type: 'POST',
                        url: 'do_edit_user.php',
                        data: data,
                        success: function(data) {
                            if(data==1){  
                                $('#after_submit').remove();
                                $('#send').after('<label class="error" id="after_submit">Your Email already registered on this web site.</label>');
                                return false;
                            }
                            else{
                                window.location.href='user.php';                                
                            }
                        }
                    });
                    
                   
                    return false;
                });
            });
        </script>        

    </head>
    <body>
        <div id="tupperware">
            <div id="status">
                <a href="<?php echo $cfg['site_url']; ?>" style="color: #fff;">Home</a> | <a href="logout.php?id=<?php echo @$user['id']; ?>" style="color: #fff;">Logout</a>
            </div>
            <h2>Opdi Admin Page</h2>     
            <form type="post" name="addForm" action="do_edit_user.php" id="addForm">
                <button type="button" name="send" id="send" value="submit">submit</button>
                <input type="hidden" id="id" name="id" value="<?php echo @$user['id']; ?>">
                    <table width="100%">    
                        <tr>
                            <td>
                                <fieldset>
                                    <legend>Edit user</legend>

                                    <table width="99%">
                                        <tr valign="top">
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Name (*)</td>
                                                        <td width="60%"><input type="text" name="name" id="name" value="<?php echo @$user['name']; ?>"/></td>
                                                    </tr>                                           
                                                </table>
                                            </td>
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Fax</td>
                                                        <td width="60%"><input type="text" name="fax" id="fax" value="<?php echo @$user['fax']; ?>"/></td>
                                                    </tr>                                            
                                                </table>
                                            </td>
                                        </tr>
                                        <tr valign="top">
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Organization (*)</td>
                                                        <td width="60%"><input type="text" name="organization" id="organization" value="<?php echo @$user['organization']; ?>"/></td>
                                                    </tr>                                           
                                                </table>
                                            </td>
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Website</td>
                                                        <td width="60%"><input type="text" name="website" id="website" value="<?php echo @$user['website']; ?>"/></td>
                                                    </tr>                                            
                                                </table>
                                            </td>
                                        </tr>
                                        <tr valign="top">
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Address</td>
                                                        <td width="60%"><input type="text" name="address" id="address" value="<?php echo @$user['address']; ?>"/></td>
                                                    </tr>                                           
                                                </table>
                                            </td>
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Password (*)</td>
                                                        <td width="60%"><input type="text" name="password" id="password" value="<?php echo @$user['password']; ?>"/></td>
                                                    </tr>                                            
                                                </table>
                                            </td>
                                        </tr>
                                        <tr valign="top">
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Phone</td>
                                                        <td width="60%"><input type="text" name="phone" id="phone" value="<?php echo @$user['phone']; ?>"/></td>
                                                    </tr>                                           
                                                </table>
                                            </td>
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Position (*)</td>
                                                        <td width="60%">
                                                            <select id="group_id" name="group_id" style="height: 24px; width: 308px;">
                                                                <option value="">----Select your position----</option>
                                                                <?php
                                                                foreach ($list_groups as $row) {
                                                                    if ($user['group_id'] == $row['id']) {
                                                                        ?>
                                                                        <option value="<?php echo $row['id']; ?>" selected><?php echo $row['name']; ?></option>
                                                                    <?php } else { ?>
                                                                        <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>

                                                                    <?php }
                                                                } ?>                                                    
                                                            </select>  
                                                        </td>
                                                    </tr>                                            
                                                </table>
                                            </td>
                                        </tr> 
                                        <tr valign="top">
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Email (*)</td>
                                                        <td width="60%"><input type="text" name="email" id="email" value="<?php echo @$user['email']; ?>"/></td>
                                                    </tr>                                           
                                                </table>
                                            </td>
                                            <td width="50%">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="40%">Active</td>
                                                        <td width="60%" align="left">
                                                            <?php if ($user['is_active']) { ?>
                                                                <input style="width:5px;" type="checkbox" id="is_active" name="is_active" value="1" checked>
                                                                <?php } else { ?>
                                                                    <input style="width:5px;" type="checkbox" id="is_active" name="is_active" value="1">
                                                                    <?php } ?>
                                                        </td>
                                                    </tr>                                           
                                                </table>
                                            </td>
                                        </tr> 
                                        <tr>
                                            <td colspan="2">
                                                <table width="100%">
                                                    <tr>
                                                        <td width="15%">Welcome text</td>
                                                        <td width="85%">
                                                            <textarea id="welcome" name="welcome" cols="200" rows="15" style="width:75%"><?php echo @$user['welcome']; ?></textarea>
                                                        </td>
                                                    </tr>                                           
                                                </table>
                                            </td>
                                        </tr>                                
                                        </table>

                                        </fieldset>
                                        </td>
                                        </tr>
                                        </table>

                                        </form>
                                        </body>
                                        </html>