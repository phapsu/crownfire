<?php

@session_start();
if (!isset($_SESSION['is_login']) || !($_SESSION['is_login'])) {
    header('Location: ' . $cfg['site_url'] . '/member-login.html');
}

include("init.php");
$users = new Users();

$exist_email = $users->checkExistEmail($_POST['email']);

if (!$exist_email) {
    $users->setName($_POST['name']);
    $users->setOrganization($_POST['organization']);
    $users->setEmail($_POST['email']);
    $users->setPassword($_POST['password']);
    $users->setPhone($_POST['phone']);
    $users->setAddress($_POST['address']);
    $users->setFax($_POST['fax']);
    $users->setWebsite($_POST['website']);
    $users->setGroup($_POST['group_id']);
    $users->setWelcome($_POST['welcome']);
    $users->setActive($_POST['is_active']);
    $users->setAdmin(0);
    
    $users->save();
    
    return 0;
}
else{    
    echo 1;
}






?>