<?php
@session_start();
if (!isset($_SESSION['is_admin']) || !($_SESSION['is_admin'])) {
    header('Location: ' . $cfg['site_url'] . '/member-login.html');
}

include("init.php");
$users = new Users();
$list_user = $users->getListUser();
?>  

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
    <head>
        <title>Opdi Admin Page</title>
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
        <link href="css/styles.css" rel="stylesheet" />
        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script>
        <link rel='shortcut icon' href="img/favicon.ico" type="image/x-icon" />	
        <style>
            .error{
                color: Red;
                font-weight: bold;
                margin-left: 10px;
            }
            .success{
                color: blueviolet;
                font-weight: bold;
                margin-left: 10px;
            }
        </style>
        
    </head>
    <body>
        <div id="tupperware">
            <div id="status">
                <a href="<?php echo $cfg['site_url']; ?>" style="color: #fff;">Home</a> | <a href="logout.php?id=<?php echo @$user['id']; ?>" style="color: #fff;">Logout</a>
            </div>
            <h2>Opdi Admin Page</h2>   
            <ul class="tools">
                    <li><a class="adduser" href="add_user.php">Add User</a></li>
            </ul>
            <table width="100%">                    
                <tr>
                    <td>
                        <fieldset>
                            <legend>List user:</legend>
                            <table cellspacing="0" cellpadding="0" border="0" class="listTable highlight">
                                <tbody><tr class="tableRowHeader">
                                <th width="5%">ID</th>
                                <th width="20%">Name</th>
                                <th width="20%">Address</th>
                                <th width="20%">Phone</th>
                                <th width="20%">Email</th>
                                <th width="5%">&nbsp; </th>
                                <th width="5%">&nbsp; </th>
                                <th width="5%">&nbsp; </th>
                                </tr>		
                                <?php foreach ($list_user as $row) {?>
                                    <tr align="center">
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo $row['name']; ?></td>
                                        <td><?php echo $row['address']; ?></td>
                                        <td><?php echo $row['phone']; ?></td>
                                        <td><?php echo $row['email']; ?></td>
                                        <td><a href="edit_user.php?user_id=<?php echo $row['id']?>"><img border="0" src="images/icons/edit.png" title="Edit User" /></a></td>
                                        <td><a href="delete_user.php?user_id=<?php echo $row['id']?>" onclick="return confirm('Are you sure you want to delete this user? \n\n ALL DATA WILL BE LOST');"><img border="0" src="images/icons/delete.png" title="Delete User" /></a></td>
                                        <td><a href="sendmail.php?user_id=<?php echo $row['id']?>"><img border="0" src="images/icons/email.png" title="Send Welcome Email" /></a></td>
                                    </tr>
                                <?php } ?>
                            </table>
                        </fieldset>
                    </td>        
                </tr>


            </table>

    </body>
</html>