<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
    <head>
        <title>Opdi Admin Page</title>
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
        <link href="css/styles.css" rel="stylesheet" />
        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> 	
        <link rel='shortcut icon' href="img/favicon.ico" type="image/x-icon" />

    </head>
    <body>    
        <div id="tupperware">
            <div id="status">
                <a href="<?php echo $cfg['site_url']; ?>" style="color: #fff;">Home</a> | <a href="logout.php?id=<?php echo @$user['id']; ?>" style="color: #fff;">Logout</a>
            </div>
            <h2>Opdi Admin Page</h2>
            <table width="100%">
                <tr>
                    <td>
                        <fieldset style="width: 500px;">
                            <legend>Customers</legend>
                            <table width="400">
                                <tr valign="top">
                                    <td><a href="user.php"><img border="0" src="images/user-group-icon.png" /></a></td>
                                    <td>
                                        Manage the users.  Create, Edit, Delete, manage their welcome information and mail to user.
                                    </td>
                                </tr>
                            </table>
                        </fieldset>
                    </td>
                    <td>
                        <fieldset style="width: 500px;">
                            <legend>Content</legend>
                            <table width="400">
                                <tr valign="top">
                                    <td><a href="content.php"><img border="0" src="images/pages-icon.png" width="48" height="48" /></a></td>
                                    <td>
                                        Manage the content
                                    </td>
                                </tr>
                            </table>
                        </fieldset>

                    </td>
                </tr>                
            </table>
    </body>
</html>