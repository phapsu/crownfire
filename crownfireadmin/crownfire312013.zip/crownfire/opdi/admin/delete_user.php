<?php
@session_start();
if (!isset($_SESSION['is_admin']) || !($_SESSION['is_admin'])) {
    header('Location: ' . $cfg['site_url'] . '/member-login.html');
}

if(isset($_REQUEST['user_id']) && $_REQUEST['user_id']!=''){
    include("init.php");
    $users = new Users();
    $list_user = $users->deleteUser($_REQUEST['user_id']);
    
    header('Location: user.php');
}
else{
    header('Location: ' . $cfg['site_url'] . '/member-login.html');
}

?>  
