<?php 
session_start();

if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['code'])) {

	if($_POST['code'] == $_SESSION['rand_code']) {
	
		// send email
		$sendto   = "raymond@opdi.org";
		$name = $_POST['name'];
		$usermail = $_POST['email'];
		$organization  = nl2br($_POST['organization']);

		$subject  = "Newsletter Sign Up";
		$headers  = "From: " . strip_tags($usermail) . "\r\n";
		$headers .= "Reply-To: ". strip_tags($usermail) . "\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html;charset=utf-8 \r\n";

		$msg  = "<html><body style='font-family:Arial,sans-serif;'>";
		$msg .= "<h2 style='font-weight:bold;border-bottom:1px dotted #ccc;'>Newsletter Sign Up</h2>\r\n";
		$msg .= "<p><strong>Sent by:</strong> ".$usermail."</p>\r\n";
		$msg .= "<p><strong>Name:</strong> ".$name."</p>\r\n";
		$msg .= "<p><strong>Organization:</strong> ".$organization."</p>\r\n";		
		$msg .= "</body></html>";


		if(@mail($sendto, $subject, $msg, $headers)) {
			echo "true";
		} else {
			echo "false";
		}
	
	} else {
	
		echo "captcha";
	
	}
	
} else {

	echo "Please fill out the entire form.";

}




?>