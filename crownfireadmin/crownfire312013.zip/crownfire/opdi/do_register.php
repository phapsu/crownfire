<?php

@session_start();
include("config/init.php");

if (@strtolower($_POST['code']) == strtolower($_SESSION['rand_code'])) {

    $users = new Users();
    
    $exist_email = $users->checkExistEmail($_POST['email']);

    if ($exist_email)
        echo 2; 
    else {
        
        $users->setName($_POST['name']);
        $users->setOrganization($_POST['organization']);
        $users->setEmail($_POST['email']);
        $users->setPassword($_POST['password']);
        $users->setPhone($_POST['phone']);
        $users->setAddress($_POST['address']);
        $users->setFax($_POST['fax']);
        $users->setWebsite($_POST['website']);
        $users->setGroup($_POST['group_id']);
        $users->setWelcome($cfg['welcome']);
        $users->setActive(0);
        $users->setAdmin(0);

        $user_id = $users->save();
        if ($user_id){
            
            //encode user_id
            $str = 'This is an encoded string=';
            $str .=$user_id;
            $str = base64_encode($str);
            
            //decode user_id
//            $code= base64_decode($str);
//
//            $pieces = explode("=", $code);
//            echo $pieces[0]; // piece1
//            echo $pieces[1]; // piece2
            
            
            
            //send mail active account            
            $name = $_POST['name'];
            $password = $_POST['password'];
            $email = $_POST['email'];
            $organization  = nl2br($_POST['organization']);

            $subject  = "Welcome to opdi.ca";
            $headers  = "From: noreply@opdi.ca\r\n";            
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html;charset=utf-8 \r\n";

            $msg  = "<html><body style='font-family:Arial,sans-serif;'>";
            $msg .= "<h2 style='font-weight:bold;border-bottom:1px dotted #ccc;'>Sign Up</h2>\r\n";
            $msg .= "<p>Deal ".$name."</p>\r\n\r\n";
            $msg .= "<p><strong>Email:</strong> ".$email."</p>\r\n";
            $msg .= "<p><strong>Password:</strong> ".$password."</p>\r\n";
            $msg .= "<p><strong>Organization:</strong> ".$organization."</p>\r\n\r\n\r\n";		
            $msg .= "<p>To complete the registration, please click on the link below or copy and paste into your browsers:</p>\r\n";
            $msg .= "<a href="+$cfg['site_url']+"'/active_account.php?code="+$str+"'>"+$cfg['site_url']+"/active_account.php?code="+$str+"</a>";
            $msg .= "</body></html>";


            if(@mail($email, $subject, $msg, $headers)) {
                    echo 1;
            } else {
                    echo 3;
            }  
            
            echo 1;
        }
            
        else
            echo 3;
    }
}
else
    echo 0;
?>
