<html>
    <head>        
        <style type="text/css">          

            .errorMessage{
                background: url(../../images/32block.png) 15px 50% no-repeat #ffd6d4;
                border-color: #911f1a;
                border: 3px solid;
                border-width: 3px 0;
                padding: 15px 15px 15px 65px;
                color: #444;
                margin: 10px 0;
                -moz-border-radius: 15px;
            }
        </style>

    </head>
    <body>
        <?php
        @session_start();
        
        if (isset($_SESSION['is_login']) && $_SESSION['is_login'] == 0) {
            echo '<div class="errorMessage">Your username and password is not valid. Please try again.</div>';
        
            unset($_SESSION['is_login']);
        }
        else if (isset($_SESSION['is_active']) && $_SESSION['is_active'] == 0) {
            echo '<div class="errorMessage">Your account is not active. Please try again.</div>';
        
            unset($_SESSION['is_active']);
        }        
        ?>
    </body>
</html>

