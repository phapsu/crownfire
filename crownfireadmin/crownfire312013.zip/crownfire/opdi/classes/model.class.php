<?php

class model {

    public function __construct() {
        global $cfg;
        $this->db = new database();
        $this->db->connect($cfg);
    }

}