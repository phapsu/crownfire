<?php

class users extends model {

    public function getName($user_id) {
        $query = "SELECT username FROM users WHERE id = " . $this->db->escape_string($user_id);
        $results = $this->db->dbQuery($query);

        if ($this->db->num_rows($results) != 0) {
            return $this->db->result($results, 0, 'username');
        }
    }

    public function getUsers($userType = 'members') {

        switch ($userType) {
            case 'admin':
                $type = 'type = 1';
                break;

            case 'members':
            default:
                $type = 'type = 2';
                break;

            case 'techs':
            default:
                $type = 'type = 3';
                break;
        }

        $fl_admin = 0;
        if ($userType == 'admin') {
            $fl_admin = 1;
            $type = '(type = 1 OR type = 2)';
        }

        $query = "SELECT * FROM users WHERE $type AND fl_deleted = 0 AND fl_admin = $fl_admin ORDER BY ID DESC";
        $results = $this->db->dbQuery($query);

        $return = array();
        while ($myrow = $this->db->row($results)) {
            $return[] = $myrow;
        }

        return $return;
    }

    public function getListUser() {

        $query = "SELECT * FROM users WHERE is_admin = 0 ORDER BY users.id ASC";
        $results = $this->db->dbQuery($query);

        $return = array();
        while ($myrow = $this->db->row($results)) {
            $return[] = $myrow;
        }

        return $return;
    }

    public function getMemberById($id) {

        $type = 'type = 2';
        $query = "SELECT * FROM users WHERE $type AND fl_deleted = 0 AND fl_admin = 0 AND users.id = $id ORDER BY users.name ASC";
        $results = $this->db->dbQuery($query);

        return $this->db->row($results);
    }

    public static function getSessionId() {
        return $_SESSION['user_id'];
    }

    public function getProfile($user_id) {

        //$userInfo = self::getUserInfo($user_id);
    }

    public function setType($type) {
        $this->type = $type;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setOrganization($organization) {
        $this->organization = $organization;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    public function setLoginUntil($login_until) {
        $this->login_until = $login_until;
    }

    public function setInfo($array) {
        $this->setEmail($array['email']);
        $this->setUsername($array['username']);
        $this->setPassword($array['password']);
    }

    public function setPhone($phone) {
        $this->phone = $phone;
    }

    public function setAddress($address) {
        $this->address = $address;
    }

    public function setFax($fax) {
        $this->fax = $fax;
    }

    public function setWebsite($website) {
        $this->website = $website;
    }

    public function setGroup($group) {
        $this->group_id = $group;
    }

    public function setWelcome($welcome) {
        $this->welcome = $welcome;
    }

    public function setActive($active) {
        $this->is_active = $active;
    }

    public function setAdmin($admin) {
        $this->is_admin = $admin;
    }   

    public function save($id = null) {

        if (!$id) {
            $query = "INSERT INTO users
                      SET
                        name 			= '" . $this->db->escape_string($this->name) . "',
                        organization            = '" . $this->db->escape_string($this->organization) . "',
                        email 			= '" . $this->db->escape_string($this->email) . "',                        
                        password 		= '" . $this->db->escape_string($this->password) . "',
                        phone                   = '" . $this->db->escape_string($this->phone) . "',
                        address                 = '" . $this->db->escape_string($this->address) . "',
                        fax                     = '" . $this->db->escape_string($this->fax) . "',
                        website                 = '" . $this->db->escape_string($this->website) . "',
                        group_id                = '" . $this->db->escape_string($this->group_id) . "',
                        welcome                 = '" . $this->db->escape_string($this->welcome) . "',
                        is_active               = '" . $this->db->escape_string($this->is_active) . "',
                        is_admin                = '" . $this->db->escape_string($this->is_admin) . "',
                        created			= NOW()";

            $result = $this->db->dbQuery($query);
            return $this->db->sql_insert_id($result);
        }
    }

    public function update($user_id=null) {
        $query = "UPDATE users
                     SET
                        name 			= '" . $this->db->escape_string($this->name) . "',
                        organization            = '" . $this->db->escape_string($this->organization) . "',
                        email 			= '" . $this->db->escape_string($this->email) . "',";                        
                        
        if(isset($this->password)){
            $query .="  password 		= '" . $this->db->escape_string($this->password) . "',";
        }
        
        $query .="      phone                   = '" . $this->db->escape_string($this->phone) . "',
                        address                 = '" . $this->db->escape_string($this->address) . "',
                        fax                     = '" . $this->db->escape_string($this->fax) . "',
                        website                 = '" . $this->db->escape_string($this->website) . "',
                        group_id                = '" . $this->db->escape_string($this->group_id) . "',";
        if(isset($this->welcome)){
            $query .="  welcome 		= '" . $this->db->escape_string($this->welcome) . "',";
        }
        $query .="      is_active               = '" . $this->db->escape_string($this->is_active) . "',
                        is_admin                = '" . $this->db->escape_string($this->is_admin) . "',
                        modified		= NOW()                    
                     WHERE
                        id = '" . $this->db->escape_string($user_id) . "'";
        $result = $this->db->dbQuery($query);
        
        return 1;
    }
    
    public function active_account($user_id=null) {
        $query = "UPDATE users
                     SET
                        is_active = 1                        
                     WHERE
                        id = '" . $this->db->escape_string($user_id) . "'";
        $result = $this->db->dbQuery($query);
        return 1;
    }

    public function deleteUser($user_id) {

        $query = "Delete from users WHERE id = '" . $this->db->escape_string($user_id) . "'";
        $results = $this->db->dbQuery($query);

        return null;
    }

    /*
     * function login user
     */

    public function login($email, $password) {
        $query = "SELECT id, is_active, is_admin FROM users WHERE is_active=1 ";

        $query .= " AND email = '" . $this->db->escape_string($email) . "' ";

        $query .= " AND password = '" . $this->db->escape_string($password) . "'";

        $results = $this->db->dbQuery($query);
        if ($this->db->num_rows($results) != 0) {

            if (!$this->db->result($results, 0, 'is_active')) {
                $_SESSION['is_active'] = 0;
                return 2;
            } else if ($this->db->result($results, 0, 'is_admin')) {
                $_SESSION['is_admin'] = 1;
                $_SESSION['is_login'] = 1;
                $_SESSION['user_id'] = $this->db->result($results, 0, 'id');
                return 3;
            } else {
                $_SESSION['is_admin'] = 0;
                $_SESSION['is_login'] = 1;
                $_SESSION['user_id'] = $this->db->result($results, 0, 'id');
                return 1;
            }
        } else {
            $_SESSION['is_login'] = 0;
            return 0;
        }
    }

    /*
     * function checkExistEmail using register new a account
     * @parameter: return 1:exist; 0: not exist
     */
    public function checkExistEmail($email) {
        $query = "SELECT id FROM users WHERE ";

        $query .= " email = '" . $this->db->escape_string($email) . "' ";

        $results = $this->db->dbQuery($query);
        if ($this->db->num_rows($results) != 0) {
            return 1;
        } else {
            return 0;
        }
    }
    
    /*
     * function checkExistEmail using user edit your account
     * @parameter: 0 : ok; 1: not ok
     */
    public function checkExistEmail_edit($email, $user_id) {
        $query = "SELECT id FROM users WHERE ";

        $query .= " email = '" . $this->db->escape_string($email) . "' ";
        
        $results = $this->db->dbQuery($query);
        
        if ($this->db->num_rows($results) != 0) {
            $current_id = $this->db->result($results, 0, 'id');
            if ($current_id!=$user_id) {
                return 1;
            }            
        } else {
            return 0;
        }
    }

    public function getUserInfo($user_id) {
        $query = "SELECT * FROM users WHERE id = " . $this->db->escape_string($user_id);
        $results = $this->db->dbQuery($query);

        if ($this->db->num_rows($results) != 0) {
            return $this->db->get_assoc($results);
        } else {
            return false;
        }
    }

    public function getUsername() {
        if ($_SESSION['user_id']) {
            $query = "SELECT username FROM users WHERE id = " . $this->db->escape_string($_SESSION['user_id']);
            $results = $this->db->dbQuery($query);

            if ($this->db->num_rows($results) != 0) {
                return $this->db->result($results, 0, 'username');
            }
        } else {
            return false;
        }
    }

    public function unique_id($argLength = 8) {
        mt_srand($this->make_seed());
        $id = uniqid(md5(mt_rand(1, 500)));
        mt_srand($this->make_seed());
        $return = substr($id, mt_rand(0, strlen($id)), $argLength);
        if ($stringlength = strlen($return) < $argLength) {
            $difference = $argLength - $stringlength;
            mt_srand($this->make_seed());
            $string = "a1A2b3B4c5c6d7D8e9EfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ";
            for ($i = 0; $i < $difference; $i++) {
                $random .= $string{mt_rand(0, strlen($string) - 1)};
            }
            // Append the string to our ID.
            $return .= $random;
            if (strlen($return) > $argLength) {
                $return = substr($return, 0, $argLength);
            }
        }
        return $return;
    }

    public function make_seed() {
        list($usec, $sec) = explode(' ', microtime());
        return (float) $sec + ((float) $usec * 100000);
    }

    public function getSiteOption($user_id, $key) {
        global $cfg;

        $query = "SELECT 
					option_value 
				  FROM 
				  	site_options
				  WHERE
				  	user_id = '" . $this->db->escape_string($user_id) . "'
				  AND
				  	option_key = '" . $this->db->escape_string($key) . "'";
        $results = $this->db->dbQuery($query);

        if ($this->db->num_rows($results) == 0) {
            // We need to add the option for them with the default value
            $default_value = $cfg['site_options'][$key];

            if (!empty($default_value)) {
                $this->setOption($user_id, $key, $default_value);
                return $default_value;
            }
        } else {
            return $this->db->result($results, 0, 'option_value');
        }
    }

    public function setOption($user_id, $key, $value) {
        $query = "DELETE FROM site_options WHERE user_id = '" . $this->db->escape_string($user_id) . "' AND option_key = '" . $this->db->escape_string($key) . "'";
        $this->db->dbQuery($query);

        $query = "INSERT INTO
						site_options
					  SET
					  	user_id			= '" . $this->db->escape_string($user_id) . "',
				  		option_key 		= '" . $this->db->escape_string($key) . "',
				  		option_value	= '" . $this->db->escape_string($value) . "'";
        $this->db->dbQuery($query);
        return true;
    }

    public function isAdmin($user_id) {
        $query = "SELECT count(*) as my_c FROM users WHERE id = '" . $this->db->escape_string($user_id) . "' AND fl_admin = 1";
        $results = $this->db->dbQuery($query);

        $count = $this->db->result($results, 0, 'my_c');

        if ($count == 0) {
            return false;
        } else {
            return true;
        }
    }

}