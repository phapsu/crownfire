<?php
include('templates/header.template.php');
?>
<title>Crownfire | Customer Login</title>
<!--<h1>Login</h1>-->

<!--<table width="60%" bgcolor="#ffffff" style="border: 1px solid #000;">
<form name="frmLoginMain" action="/members/login_do.php" method="post">
 <tr>
	  <td>
	<table cellpadding="5">
	 <tr>
	  <td>Username or Email:</td>
	  <td><input name="user_id" id="user_id" type="text" size="30" /></td>
	 </tr>
	 <tr>
	  <td>Password:</td>
	  <td><input name="password" id="password_holder" size="30" type="password" /></td>
	 </tr>
	 <tr>
	  <td>
	  <a href="javascript: void(0);" onClick="frmLoginMain.submit();" class="button floatright"><span>Login</span><span class="cap"></span></a>
	  </td>
	  <td>&nbsp;</td>
	 </tr>
	</table>
   </td>
  </tr>
 </table>
</form>-->
<h1>What Makes Crownfire Different?</h1>
<div class="homepage_content">
	<h2>People</h2>
	<ul>
		<li>People are our strength and our most important resource.</li>
		<li>Our people are trustworthy, responsible, and deserving of respect.</li>
		<li>Individual differences are accepted and appreciated.</li>
		<li>The health and safety of all our people will never be compromised.</li>
		<li>Each employee has the necessary skills, training, and authority to get the job done.</li>
		<li>Recognition and acknowledgement will be linked to individual and team performance.</li>
	</ul>
</div>
<?php
include('templates/footer.template.php');
?>