</div>
			
		</div>
	</div>
	<div id="footer">
		<div class="tupperware">
			<div class="third_col">
				<h4>Contact Us</h4>
				<ul class="telephone_list">
					<li><strong>Toll-free</strong> (877) 243-9664</li>
					<li><strong>Mississauga</strong> (905) 670-5122</li>
					<li><strong>Ajax</strong> (905) 427-8441</li>
					<li><strong>Newmarket</strong> (905) 868-8599</li>
					<li><strong>Brantford</strong> (519) 756-8962</li> 
					<li><strong>Hamilton, Burlington, Dundas</strong> (905) 521-0333</li>
					<li><strong>Fax</strong> (416) 665-1635</li>
				</ul>
			</div>
			<div class="third_col">
				<h4>Crown Fire Toronto</h4>
				<a href="#" class="map_link"><img src="img/map_toronto_new.png" alt="Google Map of Toronto Location"></a>
				<p>
					<strong>180 Trowers Rd</strong><br>
					Unit 16<br>
					Vaughan, Ontario<br>
					L4L 8A6<br>
					Canada
				</p>
			</div>
			<div class="third_col">
				<h4>Crown Fire Brantford</h4>
				<a href="#" class="map_link"><img src="img/map_brantford.png" alt="Google Map of Brantford Location"></a>
				<p>
					<strong>160 Charing Cross St.</strong><br>
					Brantford, Ontario<br>
					N3R 2J4<br>
					Canada
				</p>
			</div>
		</div>
	</div>
	<div id="copyright">
		<p class="tupperware">&copy; Copyright <?=date('Y')?> Crown Fire Equipment Ltd. All rights reserved.</p>
	</div>
</body></html>