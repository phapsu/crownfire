<?php
include('templates/header.template.php');
?>
<title>Crownfire | Job Portal Opportunities In Fire Protection & Services</title>
<h1>Jobs</h1>
<?php
include("pageincludes/jobs.inc");

include('templates/footer.template.php');
?>