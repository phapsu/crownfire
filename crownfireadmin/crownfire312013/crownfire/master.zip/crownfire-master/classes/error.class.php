<?php
class error {
	public static function displayError($error) {
		echo $error;
	}
}