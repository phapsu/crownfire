<?php
include('templates/header.template.php');
?>
<title>Catalog: Outlook of Crownfire Fire Protection & Safety Products</title>
<h1>Catalog</h1>

Stay tuned for the Crownfire Catalog.

<?php
include('templates/footer.template.php');
?>
