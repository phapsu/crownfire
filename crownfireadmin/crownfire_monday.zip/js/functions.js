function showIt(div){
	if (document.getElementById('button_add')) {
			hideAll();
	}
    if (document.getElementById) {  // for Netscape
      myDiv = document.getElementById(div);
         myDiv.style.display = 'inline';
    }

    if (document.all) {     // for IE
      eval("myDiv = "+div+";");
         myDiv.style.display = 'inline';
    }
}

function hideIt(div){
     if (document.getElementById) {  // for Netscape
       myDiv = document.getElementById(div);
          myDiv.style.display = 'none';
     }

     if (document.all) {     // for IE
       eval("myDiv = "+div+";");
          myDiv.style.display = 'none';
     }
}


function cofirmMultipleDelete(theForm) {
	if (confirm('Are you sure?')) {
		theForm.submit();
	}
}

function confirmSingleDelete() {
	if (confirm('Are you sure?')) {
		return true;
	} else {
		return false;
	}
}

function checkOptionField(field) {
	if (document.getElementById(field+'new').value == '') {
		hideIt(field+'Option'); 
		hideIt(field+'CancelLink'); 
		showIt(field+'_id'); 
		showIt(field+'NewLink');
	} else {
		hideIt(field+'_id'); 
		hideIt(field+'NewLink'); 
		showIt(field+'Option'); 		
		showIt(field+'CancelLink');	
	}
}