<?php
$title = 'Properties';
include('templates/header.inc.php');

$users = new users();
$userInfo = $users->getUserInfo($_REQUEST['user_id']);

$display->userInfoWindow($userInfo);
?>
<form method="post" action="edit_document_2_do.php">
<input type="hidden" name="type_id" value="<?=$_REQUEST['type_id']?>" />
<input type="hidden" name="user_id" value="<?=$_REQUEST['user_id']?>" />
<input type="hidden" name="property_id" value="<?=$_REQUEST['property_id']?>" />
<fieldset style="width: 800px;">
<legend>Add Document - Fire Alarm Panel Zone</legend>
<?php
include('includes/document_'.$_SESSION['type_id'].'.inc');
?>
<h3>Options</h3>
<table width="100%">
 <tr>
  <td width="20%">Document Status:</td>
  <td>
  <select name="status_id">
  	 <?php
  	 foreach($document_states as $stateArray) {
  	 	echo '<option value="'.$stateArray['id'].'">'.$stateArray['statename'].'</option>';
  	 }
  	 ?>
  	</select>
  </td>
 </tr>
  <tr>
  <td>Notification:</td>
  <td>
  
  </td>
 </tr>
</table>
<br /><br />
<button class="save" type="submit" name="submit_n" value="Save">Save</button>&nbsp; &nbsp; &nbsp; <button class="cancel" type="button" onClick="location.href='aindex.php'";>Cancel</button>
</fieldset>
 </form>
<?php
include('templates/footer.inc.php');
?>