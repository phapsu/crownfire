<?php
$title = 'Edit Document';
include('templates/header.inc.php');

// Pull our document info
$document = new document($_REQUEST['id']);

$users = new users();
$userInfo = $users->getUserInfo($_REQUEST['user_id']);

$display->userInfoWindow($userInfo);

$documentTypeName = document::getDocumentTypeById($_REQUEST['type_id']);
?>
<form method="post" action="edit_document_2_do.php">
<input type="hidden" name="id" value="<?=$_REQUEST['id']?>" />
<input type="hidden" name="type_id" value="<?=$_REQUEST['type_id']?>" />
<input type="hidden" name="user_id" value="<?=$_REQUEST['user_id']?>" />
<input type="hidden" name="property_id" value="<?=$_REQUEST['property_id']?>" />
<fieldset style="width: 800px;">
<legend>Add Document - <?=$documentTypeName?></legend>

<?php
include('includes/document_'.$_REQUEST['type_id'].'.inc');
?>
<h3>Options</h3>
<table width="100%">
 <tr>
  <td width="20%">Document Status:</td>
  <td>
  <select name="status_id">
  	 <?php
  	 foreach($document_states as $stateArray) {
  	 	echo '<option value="'.$stateArray['id'].'"';
  	 	if ($stateArray['id'] == $document->getStateId()) {
  	 		echo ' selected';
  	 	}
  	 	echo '>'.$stateArray['statename'].'</option>';
  	 }
  	 ?>
  	</select>
  </td>
 </tr>
 <tr>
  <td>Notification:</td>
  <td>
  <input type="checkbox" name="fl_email" value="1" style="width: 5px;"> Email the Customer Notification of this Document
  </td>
 </tr>
</table>
<br /><br />
<button class="save" type="submit" name="submit_n" value="Save">Save</button>&nbsp; &nbsp; &nbsp; <button class="cancel" type="button" onClick="location.href='documents.php?user_id=<?=$document->getUserId();?>&property_id=<?=$document->getPropertyId();?>'";>Cancel</button>
</fieldset>
 </form>
<?php
include('templates/footer.inc.php');
?>