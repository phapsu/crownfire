<?php
$title = 'Documents';
include('templates/header.inc.php');

$user = new users();
$user_data = $user->getUserInfo($_REQUEST['user_id']);

// And get their properties
$document = new document();
$document_list = $document->getDocumentsByPropertyId($_REQUEST['property_id']);
?>
<a href="customers.php">&lt;&lt; Back to Properties</a> <br /> &nbsp; <br />
<?=$display->userInfoWindow($user_data)?>
<br />
<ul class="tools">
	<li><a href="add_document.php?user_id=<?=$_REQUEST['user_id']?>&property_id=<?=$_REQUEST['property_id']?>" class="addproperty">Add Document</a></li>
</ul>
<br />

<table class="listTable highlight" cellspacing="0" cellpadding="0" border="0">
<tr class="tableRowHeader">
<th width="5%">ID</th>
<th width="20%">Type</th>
<th width="10%">Created</th>
<th width="10%">Last Updated</th>
<th width="5%">&nbsp; </th>
<th width="5%">&nbsp; </th>
<th width="5%">&nbsp; </th>
</tr>
<?php
foreach($document_list as $document_obj) {
	?>
	<tr align="center">
	 <td><?=$document_obj->getDocumentId();?></td>
	 <td><?=document::getDocumentTypeById($document_obj->getTypeId());?></td>
	 <td><?=date('F, jS, Y H:i:s',$document_obj->getDateAdded())?></td>
	 <td><?=date('F, jS, Y H:i:s',$document_obj->getDateUpdated())?></td>
	 <td><a href="edit_document.php?id=<?=$document_obj->getDocumentId();?>&user_id=<?=$document_obj->getUserId();?>&type_id=<?=$document_obj->getTypeId();?>&property_id=<?=$document_obj->getPropertyId();?>"><img border="0" src="images/icons/edit.png" /></a></td>
	 <td><a href="edit_document.php?id=<?=$document_obj->getDocumentId();?>&user_id=<?=$document_obj->getUserId();?>"><img border="0" src="images/icons/delete.png" /></a></td>
	 <td><a href="view_document.php?id=<?=$document_obj->getDocumentId();?>"><img border="0" src="images/icons/view.png" /></a></td>
	</tr>
<?php
}
?>
</table>
<?php
include('templates/footer.inc.php');
?>