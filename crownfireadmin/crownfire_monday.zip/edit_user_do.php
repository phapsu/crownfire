<?php
session_start();
include("includes/init.php");
///////////////////////////////////////////////////////////
// Let's unset all the errors.
unset($_SESSION['post']);
unset($_SESSION['general_error']);
///////////////////////////////////////////////////////////
$err = false;
$required = array('name','email','username','password');

if ($_POST['email']) {
	if (!$validate->validEmail($_POST['email'])) {
		$_SESSION['general_error'][] = "Invalid email address";
		$_SESSION['post']['errors'][] = 'email';
		$err = true;
	}
}

if ($_POST['username']) {
	$query = "SELECT count(*) AS my_c FROM users WHERE username = '".$db->escape_string($_POST['username'])."'";
	$db->dbQuery($query);
}


if ($validate->validateForm($required) && !$err) {
	$user = new users();
	$user->setName($_POST['name']);
	$user->setType(2);
	$user->setEmail($_POST['email']);
	$user->setUsername($_POST['username']);
	$user->setPassword($_POST['password']);
	$id = $user->save($_POST['user_id']);
	header('Location: view_properties.php?user_id='.$id.'&us=1');
} else {
	header('Location: edit_user.php?user_id='.$_POST['user_id']);	
}
?>