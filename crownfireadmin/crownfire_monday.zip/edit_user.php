<?php
$title = 'Properties';
include('templates/header.inc.php');

if ($validate->is_error()) {
	$user_info = $validate->get_error_data();
} elseif ($_REQUEST['user_id']) {
	$users = new users();
	$user_info = $users->getUserInfo($_REQUEST['user_id']);
}
?>

<?php
$display->error_message();
?>

<fieldset style="width: 500px;">
  <legend>Manage User</legend>
	<table cellpadding="8">
	<form method="post" action="edit_user_do.php">
	 <tr valign="middle">
	  <td><b><?=$display->formElement('Name:','name',1);?></b></td>
	  <td><input type="text" name="name" id="name" value="<?=$user_info['name']?>" /></td>
	 </tr>
	 <tr valign="middle">
	  <td><b><?=$display->formElement('Username:','username',1);?></b></td>
	  <td><input type="text" name="username" id="name" value="<?=$user_info['username']?>" /></td>
	 </tr>
	 <tr valign="middle">
	  <td><b><?=$display->formElement('Password:','password',1);?></b></td>
	  <td><input type="text" name="password" id="name" value="<?=$user_info['password']?>" /></td>
	 </tr>
	 <tr valign="middle">
	  <td><b><?=$display->formElement('Email:','email',1);?></b></td>
	  <td><input type="text" name="email" id="name" value="<?=$user_info['email']?>" /></td>
	 </tr>
	 <tr>
	 <td>&nbsp; </td>
	  <td> <button class="save" type="submit" name="submit_n" value="Save Property">Save User</button>&nbsp; &nbsp; &nbsp; <button class="cancel" type="button" onClick="location.href='view_properties.php?user_id=<?=$_REQUEST['user_id']?>'";>Cancel</button></td>
	 </tr>
	 <input type="hidden" name="user_id" value="<?=$_REQUEST['user_id']?>" />
	 </form>
	</table>
</fieldset>



<?php
include('templates/footer.inc.php');
?>