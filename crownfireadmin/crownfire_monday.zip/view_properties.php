<?php
$title = 'Properties';
include('templates/header.inc.php');

$user = new users();
$user_data = $user->getUserInfo($_REQUEST['user_id']);

// And get their properties
$property = new property();
$property_list = $property->getListByUserId($_REQUEST['user_id']);
?>
<a href="customers.php"><< Back to Customers</a> <br /> &nbsp; <br />
<?=$display->userInfoWindow($user_data)?>
<br />
<ul class="tools">
	<li><a href="edit_property.php?user_id=<?=$_REQUEST['user_id']?>" class="addproperty">Add Property</a></li>
	<li style="float: right; padding-right: 10px;"><a href="property_history.php?user_id=<?=$_REQUEST['user_id']?>" class="history">View History</a></li>
</ul>
<br />

<table class="listTable highlight" cellspacing="0" cellpadding="0" border="0">
<tr class="tableRowHeader">
<th width="5%">ID</th>
<th width="20%">Name</th>
<th width="20%">Address</th>
<th width="5%">&nbsp; </th>
<th width="5%">&nbsp; </th>
<th width="5%">&nbsp; </th>
</tr>
<?php
foreach($property_list as $property_obj) {
	?>
	<tr align="center">
	 <td><?=$property_obj->getPropertyId();?></td>
	 <td><?=$property_obj->getName();?></td>
	 <td><?=$property_obj->getAddress1();?>, <?=$property_obj->getAddress2();?><br /><?=$property_obj->getCity();?>, <?=$property_obj->getProvince();?><br /><?=$property_obj->getCountry();?></td>
	 <td><a href="edit_property.php?id=<?=$property_obj->getPropertyId();?>&user_id=<?=$property_obj->getUserId();?>"><img border="0" src="images/icons/edit.png" /></a></td>
	 <td><a href="view_properties.php?user_id=<?=$property_obj->getUserId();?>"><img border="0" src="images/icons/delete.png" /></a></td>
	 <td><a href="documents.php?user_id=<?=$property_obj->getUserId();?>&property_id=<?=$property_obj->getPropertyId();?>"><img border="0" src="images/icons/template.png" /></a></td>
	</tr>
<?php
}
include('templates/footer.inc.php');
?>