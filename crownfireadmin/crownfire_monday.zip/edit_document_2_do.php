<?php
session_start();
include("includes/init.php");
///////////////////////////////////////////////////////////
// Let's unset all the errors.
unset($_SESSION['post']);
unset($_SESSION['general_error']);
///////////////////////////////////////////////////////////

$err = 0;
// Important stuff
$user_id		= $_POST['user_id'];
$property_id	= $_POST['property_id'];
$type_id		= $_POST['type_id'];
$state_id		= $_POST['state_id'];
$document_id	= $_REQUEST['id'];
$required = array();

if ($validate->validateForm($required) && $err != 1) {
	
	// Ok, we validated.  First we need to add this document into the generic table
	if ($_REQUEST['id']) {
		$document = new document($_REQUEST['id']);
	} else {
		$document = new document();
		$document->setDateAdded(time());
	}
	$document->setUserId($user_id);
	$document->setPropertyId($property_id);
	$document->setTypeId($type_id);
	$document->setStateId($state_id);
	$document->setDateUpdated(time());
	$new_document_id = $document->save();
	
	// Now, depending on the document type_id we need to save data
	switch($type_id) {
		case '1':
			// We need to save all the data in the head of the form.  Since these always change we have 
			// to check on each one.  SIGH.
			$save_array = array('document_id'			=> $new_document_id,
								'customer_name' 		=> $_POST['customer_name'],
								'technician'			=> $_POST['technician'],
								'address'				=> $_POST['address'],
								'inspection_date'		=> $_POST['inspection_date'],
								'city'					=> $_POST['city'],
								'man_name_model'		=> $_POST['man_name_model']);
			$document = new document();
			if ($document_id) {
				$document->saveData('document_data_1_head',$save_array,'document_id',$document_id);
			} else {
				$document->saveData('document_data_1_head',$save_array);
			}
			
			// This form has an array of fields too
			if (is_array($_POST['zone_name'])) {
				
				// We'll delete these records first.
				$document->deleteData('document_data_1_zones','document_id',$document_id);
				
				// Now add them in.
				foreach($_POST['zone_name'] as $key => $zone_name) {
					if (empty($zone_name)) {
						continue;
					}
					$save_array = array('document_id'			=> $new_document_id,
										'zone_name'				=> $zone_name,
										'zone_num'				=> $_POST['zone_num'][$key],
										'alarm_circuit'			=> $_POST['alarm_circuit'][$key],
										'supervisory_circuit'	=> $_POST['supervisory_circuit'][$key]);
					$document->saveData('document_data_1_zones',$save_array);		
				}
			}
		break;
		
		case '3':
			
			$save_array = array('document_id'			=> $new_document_id,
								'customer_name' 		=> $_POST['customer_name'],
								'technician_1'			=> $_POST['technician_1'],
								'technician_2'			=> $_POST['technician_2'],
								'address'				=> $_POST['address'],
								'inspection_date'		=> $_POST['inspection_date'],
								'city'					=> $_POST['city']);
			$document = new document();
			if ($document_id) {
				$document->saveData('document_data_3_head',$save_array,'document_id',$document_id);
			} else {
				$document->saveData('document_data_3_head',$save_array);
			}
			
			$save_array = array('document_id'			=> $new_document_id,
								'deficiencies'			=> $_POST['deficiencies'], 
								'recommendations'		=> $_POST['recommendations'],	
								'remarks'				=> $_POST['remarks']);
			if ($document_id) {
				$document->saveData('document_data_3_summary',$save_array,'document_id',$document_id);
			} else {
				$document->saveData('document_data_3_summary',$save_array);
			}
			
			// Need to save the question answers
			document::saveQuestions($type_id,$new_document_id);
			
			
		break;
		
		case '4':
			$save_array = array('document_id'			=> $new_document_id,
								'customer_name' 		=> $_POST['customer_name'],
								'technician'			=> $_POST['technician'],
								'address'				=> $_POST['address'],
								'inspection_date'		=> $_POST['inspection_date'],
								'city'					=> $_POST['city'],
								'contact'				=> $_POST['contact'],
								'site'					=> $_POST['site']);
			$document = new document();
			if ($document_id) {
				$document->saveData('document_data_4_head',$save_array,'document_id',$document_id);
			} else {
				$document->saveData('document_data_4_head',$save_array);
			}
			
			// Save the fire extinguisher / fire hose report
			if (is_array($_POST['report_num'])) {
				
				// We'll delete these records first.
				$document->deleteData('document_data_4_report','document_id',$document_id);
				
				// Now add them in.
				foreach($_POST['report_num'] as $key => $report_num) {
					if (empty($report_num)) {
						continue;
					}
					$save_array = array('document_id'			=> $new_document_id,
										'report_num'			=> $_POST['report_num'][$key],
										'location'				=> $_POST['location'][$key],
										'size_type'				=> $_POST['size_type'][$key],
										'manufacture'			=> $_POST['manufacture'][$key],
										'serial'				=> $_POST['serial'][$key],
										'manufacture_date'		=> $_POST['manufacture_date'][$key],
										'last_h_test'			=> $_POST['last_h_test'][$key],
										'next_h_test'			=> $_POST['next_h_test'][$key],
										'next_six_year'			=> $_POST['next_six_year'][$key],
										'remarks'				=> $_POST['remarks'][$key]);
					$document->saveData('document_data_4_report',$save_array);
				}
			}
		break;
		
		case '5':
			$save_array = array('document_id'			=> $new_document_id,
								'customer_name' 		=> $_POST['customer_name'],
								'technician'			=> $_POST['technician'],
								'address'				=> $_POST['address'],
								'inspection_date'		=> $_POST['inspection_date'],
								'city'					=> $_POST['city'],
								'contact'				=> $_POST['contact'],
								'site'					=> $_POST['site']);
			$document = new document();
			if ($document_id) {
				$document->saveData('document_data_5_head',$save_array,'document_id',$document_id);
			} else {
				$document->saveData('document_data_5_head',$save_array);
			}
			
			// Save the fire extinguisher / fire hose report
			if (is_array($_POST['unit_type'])) {
				
				// We'll delete these records first.
				$document->deleteData('document_data_5_form','document_id',$document_id);
				
				// Now add them in.
				foreach($_POST['unit_type'] as $key => $unit_type) {
					if (empty($unit_type)) {
						continue;
					}
					$save_array = array('document_id'			=> $new_document_id,
										'unit_type'				=> $_POST['unit_type'][$key],
										'location'				=> $_POST['location'][$key],
										'time_illuminated'		=> $_POST['time_illuminated'][$key],
										'pass_or_fail'			=> $_POST['pass_or_fail'][$key],
										'unit_voltage'			=> $_POST['unit_voltage'][$key],
										'unit_watts'			=> $_POST['unit_watts'][$key],
										'num_batteries'			=> $_POST['num_batteries'][$key],
										'size_batteries'		=> $_POST['size_batteries'][$key]);
					$document->saveData('document_data_5_form',$save_array);
				}
			}
		break;
		
		case '6':
			$save_array = array('document_id'			=> $new_document_id,
								'customer_name' 		=> $_POST['customer_name'],
								'technician'			=> $_POST['technician'],
								'address'				=> $_POST['address'],
								'inspection_date'		=> $_POST['inspection_date']);
			$document = new document();
			if ($document_id) {
				$document->saveData('document_data_6_head',$save_array,'document_id',$document_id);
			} else {
				$document->saveData('document_data_6_head',$save_array);
			}
			
			// Valve Testing
			
			// Delete first
			$document->deleteData('document_data_6_valve','document_id',$document_id);
			
			// Add options
			if(is_array($_POST['testingOption'])) {
				foreach($_POST['testingOption'] as $key => $value) {
					if ($value['size_a'] != '' || $value['size_b'] != '') {
						$save_array = array('document_id'	=> $new_document_id,
											'option_id'		=> $key,
											'size_a'		=> $value['size_a'],
											'size_b'		=> $value['size_b']);
						$document->saveData('document_data_6_valve',$save_array);
					}
				}
			}
			
			// Need to save the question answers
			document::saveQuestions($type_id,$new_document_id);
		break;
	}
	
	header('Location: documents.php?user_id='.$user_id.'&property_id='.$property_id);
} else {
	header('Location: edit_property.php?id='.$_POST['id'].'&user_id='.$_POST['user_id']);	
}
?>