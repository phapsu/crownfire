<?php
$title = 'Properties';
include('templates/header.inc.php');

$users = new users();
$userList = $users->getUsers();
?>
<h1>Customers</h1>
<ul class="tools">
	<li><a href="edit_user.php" class="adduser">Add Customer</a></li>
</ul>

<table class="listTable highlight" cellspacing="0" cellpadding="0" border="0">
<tr class="tableRowHeader">
<th width="15%">ID</th>
<th width="20%">Customer Name</th>
<th width="20%">Customer Email</th>
<th width="20%">No. of Properties</th>
<th width="5%" >&nbsp; </th>
<th width="5%" >&nbsp; </th>
</tr>
<?php
foreach($userList as $userArray) {
	?>
	<tr align="center">
	 <td><?=$userArray['id']?></td>
	 <td><?=$userArray['name']?></td>
	 <td><?=$userArray['email']?></td>
	 <td>5</td>
	 <td><a href="view_properties.php?user_id=<?=$userArray['id']?>"><img border="0" src="images/icons/edit.png" /></a></td>
	 <td><a href="send_info.php?user_id=<?=$userArray['id']?>"><img border="0" src="images/icons/email.png" /></a></td>
	</tr>
<?php
}
include('templates/footer.inc.php');
?>